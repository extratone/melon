window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "popular internet meme/frequent trending topic. i make musik",
        "website" : "https://t.co/b4SZG7gPaY",
        "location" : "Drakesville, Iowa"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1601343772/Facebook_profile.JPG",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/396069845/1375880951"
    }
  }
]