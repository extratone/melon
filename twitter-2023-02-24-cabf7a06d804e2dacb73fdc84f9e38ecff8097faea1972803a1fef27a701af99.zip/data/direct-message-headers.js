window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "21176402-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "188360534108815362",
            "senderId" : "21176402",
            "recipientId" : "396069845",
            "createdAt" : "2012-04-06T20:20:25.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "55739305-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "364151769623842816",
            "senderId" : "55739305",
            "recipientId" : "396069845",
            "createdAt" : "2013-08-04T22:32:02.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "364120788099534848",
            "senderId" : "55739305",
            "recipientId" : "396069845",
            "createdAt" : "2013-08-04T20:28:55.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "361999744131792897",
            "senderId" : "55739305",
            "recipientId" : "396069845",
            "createdAt" : "2013-07-30T00:00:39.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "87598709-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "253529696371871744",
            "senderId" : "87598709",
            "recipientId" : "396069845",
            "createdAt" : "2012-10-03T16:19:24.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "251810994949595136",
            "senderId" : "87598709",
            "recipientId" : "396069845",
            "createdAt" : "2012-09-28T22:29:54.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "91454037-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "241289515090710528",
            "senderId" : "91454037",
            "recipientId" : "396069845",
            "createdAt" : "2012-08-30T21:41:18.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "393089681-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "189391572259979264",
            "senderId" : "393089681",
            "recipientId" : "396069845",
            "createdAt" : "2012-04-09T16:37:24.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "393111504-396069845",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "189144828687286274",
            "senderId" : "393111504",
            "recipientId" : "396069845",
            "createdAt" : "2012-04-09T00:16:55.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "396069845-427368646",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "246858583386492928",
            "senderId" : "427368646",
            "recipientId" : "396069845",
            "createdAt" : "2012-09-15T06:30:47.000Z"
          }
        }
      ]
    }
  }
]