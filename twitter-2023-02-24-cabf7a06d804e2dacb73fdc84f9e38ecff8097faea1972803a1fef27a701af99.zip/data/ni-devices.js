window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "udid" : "AE2353F0-2F8F-4918-9A1D-8AA96680767D",
        "deviceType" : "Twitter for iOS",
        "token" : "3XaPoEdxv3wpjvRsnBB1mGHM3WOMyoDAqB9d0ddK4bk=",
        "updatedDate" : "2016.01.02",
        "createdDate" : "2016.01.02"
      }
    }
  },
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "7.7.2",
        "udid" : "B83C4723-6709-4C7F-802B-27147517B3DA",
        "deviceType" : "Twitter for iOS",
        "token" : "4+pKikVyNYjhz7Nz030Hb2MP98N95pYo9lwn13iekKw=",
        "updatedDate" : "2017.09.23",
        "createdDate" : "2016.04.13"
      }
    }
  }
]