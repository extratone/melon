window.YTD.lists_created.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ihadtopee/lists/people-to-spam"
    }
  }
]