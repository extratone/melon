window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "tc2j462hILSiXpMfzTsCR8eIEgsRj9ZyrwHQhQpl",
      "createdAt" : "2021-11-19T06:06:49.101Z",
      "lastSeenAt" : "2021-11-19T06:06:49.103Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "f7vQFI72FGcxNO2KGMxzlh2akFGqfVBIBDnf99tv",
      "createdAt" : "2021-12-13T05:51:43.753Z",
      "lastSeenAt" : "2021-12-13T05:51:43.754Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "Es6udCKUdEWZLcWUJzxL0MdnAQCqUmNRwCKaKviK",
      "createdAt" : "2021-12-08T10:54:22.643Z",
      "lastSeenAt" : "2021-12-14T21:54:07.113Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Zxrn9H4M7oQZNmfIs58dBEmZ3sEOZhloNs1a8KcZ",
      "createdAt" : "2021-11-23T01:59:30.066Z",
      "lastSeenAt" : "2021-12-15T00:55:36.263Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "JowwB2BxOF7D3uN3zrUhE4m6CpwqqYpxpn9f0mqV",
      "createdAt" : "2021-10-21T09:43:55.662Z",
      "lastSeenAt" : "2022-02-20T10:12:03.271Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "OIKPOVpu1xOMC9wASdNR1X4pnotW4fvgbUhxxyMN",
      "createdAt" : "2022-02-22T05:28:58.265Z",
      "lastSeenAt" : "2022-02-22T07:49:13.660Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "0D5akGAVPcaVsMVn4nVfmdPM6VVVQzbWtvJHoXlJ",
      "createdAt" : "2021-12-22T00:37:08.967Z",
      "lastSeenAt" : "2022-04-21T15:17:03.453Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ojXyA3zLR1zY4xzNLO8bzK7Yat0sUOmMcGEsGdj9",
      "createdAt" : "2022-05-15T01:19:15.484Z",
      "lastSeenAt" : "2022-05-15T01:19:15.486Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "c7wBxRUgHXQAdilBYIJg6RSkM4J6Czkv9TXTz5Dj",
      "createdAt" : "2022-06-07T04:24:01.140Z",
      "lastSeenAt" : "2022-06-09T09:23:47.108Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "5rw3uiZXhO1T9SnJ279S6pCW3R1t2CQdQXhhIMS3",
      "createdAt" : "2022-07-15T06:01:23.022Z",
      "lastSeenAt" : "2022-07-15T06:01:23.023Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "12JQ3ZyTlj8HKkNjdG7De63qgA6zy6OcpHvfTslY",
      "createdAt" : "2022-06-17T01:23:41.995Z",
      "lastSeenAt" : "2022-07-15T06:07:41.944Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "oMuqqdfO8EAZNJtOBS1IzR2jR1kTzGmEUL6RlZKg",
      "createdAt" : "2022-07-16T18:13:01.215Z",
      "lastSeenAt" : "2022-07-16T18:13:01.216Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "loevIogKZJxvFVZ9rA9hqXBoJGW8Y7dIQsgx2B6a",
      "createdAt" : "2022-08-07T10:51:56.437Z",
      "lastSeenAt" : "2022-08-07T10:51:56.438Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "Q59cLzStKGJBURsQ5ZEoLV2nFpa5RAdWLIUHIbNk",
      "createdAt" : "2022-10-29T01:49:00.489Z",
      "lastSeenAt" : "2022-10-29T01:49:00.490Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "eS79tDiEyABE7ByyGZDNLxKdUmIQ9aeTpP5Pwic7",
      "createdAt" : "2023-01-04T20:59:50.056Z",
      "lastSeenAt" : "2023-01-04T20:59:50.058Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "eb5zZBU03CF7vYKfIy2jIp7sQjbOfyXn0TumrXNL",
      "createdAt" : "2023-01-06T00:54:34.529Z",
      "lastSeenAt" : "2023-01-06T00:54:34.531Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "jjvEzUBMeZXkhQNnPt3iWRlOlsiyJjxslQypK6kG",
      "createdAt" : "2023-01-08T05:40:01.698Z",
      "lastSeenAt" : "2023-01-08T05:40:01.700Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "JoGCMBY7IebyxOaUBUnPV2TNZmWDLF8P4kp6QM1k",
      "createdAt" : "2023-01-09T13:40:10.696Z",
      "lastSeenAt" : "2023-01-09T13:40:10.698Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "wYmFqUUwUjaMAQUz4Fl1Q4xLI7iLunNTZ75N5pfL",
      "createdAt" : "2023-01-19T09:22:31.592Z",
      "lastSeenAt" : "2023-01-19T09:22:31.594Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "HXqwLc0Up1njMgudSogRBtCGG6Hfrxu0QFhzLig0",
      "createdAt" : "2023-01-23T04:10:28.759Z",
      "lastSeenAt" : "2023-01-23T04:10:28.760Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "3A9gccBAdgywLhPJdwwdw9I0jzpcH52NmBcdGILV",
      "createdAt" : "2023-02-23T04:47:48.369Z",
      "lastSeenAt" : "2023-02-23T04:47:48.370Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]